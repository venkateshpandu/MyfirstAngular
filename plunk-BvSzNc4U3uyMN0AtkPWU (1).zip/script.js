// Code goes here

(function()
{
  var app=angular.module("gitHubViewer",[]);
  var mainCtrl=function($scope,$http,$interval)
  {
    $scope.title="Git Hub Repository";
    $scope.tagLine="from github.co";
    $scope.username="angular";
    $scope.repoSortOrder="-stargazers_count";
    $scope.countdown=5;
    var decrementCountDown=function()
    {
      $scope.countdown-=1;
      if ($scope.countdown<1)
      {
        $scope.search($scope.username);
      }
      
    };
    var startCountDown=function()
    {
      $interval(decrementCountDown,1000,5);
    };
    
    var onUserRequest=function(response)
    {
      $scope.repos=response.data;
    };
    var onUserComplete=function(response)
    {
      $scope.user=response.data;
      $http.get($scope.user.repos_url)
      .then(onUserRequest,onError);
    };
    var onError=function(error)
    {
      $scope.error="couldn't fetch the details";
    };
    $scope.search=function(username)
    {
      $http.get("https://api.github.com/users/"+username)
      .then(onUserComplete,onError);
      
    };
    startCountDown();
  };
  app.controller("mainCtrl",mainCtrl);
}());